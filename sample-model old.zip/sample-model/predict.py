#!/usr/bin/env python3
"""
Sample Prediction Model for Sona Gameathon
==========================================
Reads /data/input.json and predicts TOTAL INNINGS SCORES for both innings.

CONTRACT:
  Input:  /data/input.json  (mounted read-only by Docker)
  Output: JSON to stdout → { "predictedRunsInning1": int, "predictedRunsInning2": int }

SCORING:
  MAE = |predicted - actual| per innings.  Total error = errI1 + errI2.
  Lower cumulative error across all matches = higher leaderboard rank.
  Container failure / timeout = 999 penalty per innings.

INPUT JSON SCHEMA (from admin CSV upload):
  {
    "matchNumber": 1,
    "team1": "Mumbai Indians",
    "team2": "Kolkata Knight Riders",
    "stadium": "MA Chidambaram Stadium",
    "tossWinner": "Mumbai Indians",
    "tossDecision": "bat",
    "matchData": {                          ← from CSV upload (may be absent)
      "innings1": {
        "battingTeam": "Mumbai Indians",
        "bowlingTeam": "Kolkata Knight Riders",
        "batsmen": ["Quinton de Kock", "Rohit Sharma", ...],
        "bowlers": ["Sunil Narine", "Varun Chakravarthy", ...]
      },
      "innings2": {
        "battingTeam": "Kolkata Knight Riders",
        "bowlingTeam": "Mumbai Indians",
        "batsmen": ["Shreyas Iyer", "Venkatesh Iyer", ...],
        "bowlers": ["Jasprit Bumrah", "Trent Boult", ...]
      }
    }
  }

OUTPUT: Total predicted runs for each innings (full 20 overs).
"""

import json
import sys

# ─── Configuration ──────────────────────────────────────────────
INPUT_PATH = "/data/input.json"

# Typical T20 total innings score range
DEFAULT_INNINGS_SCORE = 165
MIN_INNINGS_SCORE = 80
MAX_INNINGS_SCORE = 280

# Venue-based adjustments (positive = batting friendly, high-scoring)
VENUE_ADJUSTMENTS = {
    "wankhede stadium":       +15,
    "chinnaswamy stadium":    +20,
    "m. chinnaswamy stadium": +20,
    "eden gardens":           +5,
    "chepauk":                -15,
    "ma chidambaram stadium": -15,
    "feroz shah kotla":       -10,
    "arun jaitley stadium":   -10,
    "rajiv gandhi stadium":   +5,
    "narendra modi stadium":  +10,
    "dharamsala":             -5,
    "mohali":                 +8,
    "punjab cricket association stadium": +8,
    "sawai mansingh stadium": +5,
    "brabourne stadium":      +10,
    "dy patil stadium":       +8,
    "maharashtra cricket association stadium": +5,
    "holkar stadium":         +12,
    "green park":             -5,
    "uppal":                  +5,
}

# Known strong batting teams get a small boost
STRONG_BATTING_TEAMS = {
    "mumbai indians": 5,
    "royal challengers bangalore": 8,
    "royal challengers bengaluru": 8,
    "kolkata knight riders": 3,
    "rajasthan royals": 3,
    "gujarat titans": 2,
    "chennai super kings": 0,   # Chepauk neutralizes batting
    "punjab kings": 5,
    "delhi capitals": 2,
    "sunrisers hyderabad": 7,
    "lucknow super giants": 2,
}


def load_input(filepath: str) -> dict:
    """Read and return the match input JSON."""
    try:
        with open(filepath, "r") as f:
            return json.load(f)
    except Exception as e:
        print(json.dumps({"error": f"Failed to read input: {e}"}))
        sys.exit(1)


def get_venue_adjustment(stadium: str) -> int:
    """Return a run adjustment based on the stadium."""
    if not stadium:
        return 0
    key = stadium.strip().lower()
    if key in VENUE_ADJUSTMENTS:
        return VENUE_ADJUSTMENTS[key]
    for venue, adj in VENUE_ADJUSTMENTS.items():
        if venue in key or key in venue:
            return adj
    return 0


def get_team_strength(team_name: str) -> int:
    """Return a batting strength adjustment for known teams."""
    if not team_name:
        return 0
    key = team_name.strip().lower()
    if key in STRONG_BATTING_TEAMS:
        return STRONG_BATTING_TEAMS[key]
    for team, adj in STRONG_BATTING_TEAMS.items():
        if team in key or key in team:
            return adj
    return 0


def get_toss_adjustment(toss_winner: str, toss_decision: str,
                        batting_team: str, innings_num: int) -> int:
    """
    Adjust based on toss outcome and batting order.
    - Batting first after winning toss & choosing bat → +5
    - Chasing (2nd innings) → slight boost for known target (+3)
    """
    if not toss_winner or not batting_team:
        return 0
    batting_won_toss = toss_winner.strip().lower() == batting_team.strip().lower()
    chose_bat = toss_decision.strip().lower() == "bat"

    if innings_num == 1:
        if batting_won_toss and chose_bat:
            return 5   # Confident batting first
        elif not batting_won_toss and not chose_bat:
            return 3   # Put in to bat
    else:
        # 2nd innings: chasing teams often score more in successful chases
        return 3
    return 0


def predict_innings(innings_data: dict | None, stadium: str,
                    toss_winner: str, toss_decision: str,
                    innings_num: int) -> int:
    """
    Predict total innings score (full 20 overs).

    Uses: venue, team strength, toss, and lineup depth.
    """
    base = DEFAULT_INNINGS_SCORE

    venue_adj = get_venue_adjustment(stadium)

    if innings_data:
        batting_team = innings_data.get("battingTeam", "")
        team_adj = get_team_strength(batting_team)
        toss_adj = get_toss_adjustment(toss_winner, toss_decision,
                                       batting_team, innings_num)

        # Lineup depth: more batsmen listed = deeper batting lineup
        batsmen_count = len(innings_data.get("batsmen", []))
        lineup_adj = min(batsmen_count * 2, 10)  # +2 per batsman, cap at +10

        # Bowling strength of opponents: more bowlers = stronger attack = fewer runs
        bowlers_count = len(innings_data.get("bowlers", []))
        bowling_penalty = min(bowlers_count * 2, 8)  # -2 per bowler, cap at -8

        predicted = base + venue_adj + team_adj + toss_adj + lineup_adj - bowling_penalty
    else:
        predicted = base + venue_adj

    return max(MIN_INNINGS_SCORE, min(MAX_INNINGS_SCORE, predicted))


def main():
    """Entry point: read input, predict, output JSON."""
    data = load_input(INPUT_PATH)

    # Extract top-level fields
    stadium = data.get("stadium", "")
    toss_winner = data.get("tossWinner", "")
    toss_decision = data.get("tossDecision", "")

    # Extract enriched match data (from admin CSV upload)
    match_data = data.get("matchData", {})
    innings1 = match_data.get("innings1") if match_data else None
    innings2 = match_data.get("innings2") if match_data else None

    # Predict total score for each innings
    predicted_i1 = predict_innings(innings1, stadium, toss_winner,
                                   toss_decision, innings_num=1)
    predicted_i2 = predict_innings(innings2, stadium, toss_winner,
                                   toss_decision, innings_num=2)

    # Output prediction
    result = {
        "predictedRunsInning1": predicted_i1,
        "predictedRunsInning2": predicted_i2,
    }
    print(json.dumps(result))


if __name__ == "__main__":
    main()
